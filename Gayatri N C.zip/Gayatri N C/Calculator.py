def add() :
    a = float(input("Enter the first number: "))
    b = float(input("Enter the second number: "))
    Result = a+b
    print(a,"+",b,"=",Result)
def sub() :
    a = float(input("Enter the first number: "))
    b = float(input("Enter the second number: "))
    Result = a - b
    print(a,"-",b,"=",Result)
def multi() :
    a = float(input("Enter the first number: "))
    b = float(input("Enter the second number: "))
    Result = a*b 
    print(a,"*",b,"=",Result) 
def div() :
    a = float(input("Enter the first number: "))
    b = float(input("Enter the second number: "))
    if b==0 :
       print("Indefinite value, cannot be divided with zero...")  
    else:
       Result = a/b
       print(a,"/",b,"=",Result) 
print("    Menu    ")
print("1.Addition")
print("2.Subtraction")
print("3.Multiplication")
print("4.Division")
print("5.Exit")
choice = int(input("Enter your choice: "))
while choice!=5 : 
    if choice==1 :
       add()
    elif choice==2 :
       sub()
    elif choice==3 :
       multi()
    elif choice==4 :
       div()
    else:
       print("Invalid choice! Please try again...")
    choice = int(input("Enter your next choice: "))
if choice==5 :
   print("Exit...")