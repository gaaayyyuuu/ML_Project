maths = float(input("Enter the mark of maths: "))
physics = float(input("Enter the mark of physics: "))
chemistry = float(input("Enter the mark of chemistry: "))
per = (maths+physics+chemistry)/3
print("Percentage = ",per,"%")