try :
    num = int(input("Enter a number: "))
except :
    print("String argument error")
    