str = input("Enter a sentence: ")
list = ["A","a","E","e","I","i","O","o","U","u"]
count = 0
for i in str:
    if i in list:
         count += 1
print("No: of vowels =",count)
