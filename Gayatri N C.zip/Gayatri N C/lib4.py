import matplotlib.pyplot as plt
x = [1,2,3,4]
y = [10,20,30,40]
plt.bar(x,y)
plt.show()