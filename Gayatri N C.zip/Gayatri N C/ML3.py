import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
df = pd.read_csv("train.csv")
print(df.head())
print(df.tail())                                                
print(df.columns)
print(df.info())
features = ["GrLivArea","BedroomAbvGr","FullBath","HalfBath","OverallQual"]
y = df["SalePrice"]
x = df[features]
print(y.head())
print(x.head()) 
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size = 0.2,random_state = 42)
model = LinearRegression()
model.fit(x_train,y_train)
pred = model.predict(x_test)
print(pred)
mse = mean_squared_error(pred,y_test)
r2score = r2_score(pred,y_test)
print(mse)
print(r2score)
plt.scatter(x["FullBath"],y,color = "blue",label = "Actual Data")
plt.plot(x["FullBath"],model.predict(x),color = "red",label = "Regression Line")
plt.xlabel("FullBath")
plt.ylabel("SalePrice")
plt.title("Linear Regression")
plt.legend()        
plt.show()
