with open("fy.txt",'w') as file :
    file.write("Wonderful")
with open("fy.txt",'r') as file :
    a = file.read()
    print(a)