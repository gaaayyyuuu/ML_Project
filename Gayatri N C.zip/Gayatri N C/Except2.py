try :
    a = 10/0
except :
    print("Zero division error")
finally :
    print("Error detected")