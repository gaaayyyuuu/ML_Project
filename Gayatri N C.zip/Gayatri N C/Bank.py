def deposit(depo,balance):
    balance += depo
    return(balance)
def withdraw(amount,balance) :
        balance -= amount
        return(balance)
def bal(name,balance) :
    print("Name : ",name)
    print("Balance : ",balance)
print("    Bank Menu    ")
print("1.Deposit")
print("2.Withdraw")
print("3.Balance")
print("4.Exit")
name = input("Enter your name: ")
balance = float(input("Enter the balance amount: "))
choice = float(input("Enter your choice: "))
while choice!=4 :
    if choice==1 :
        depo = float(input("Enter the deposit amount: "))
        balance = deposit(depo,balance)  
        print("Deposit successfull")      
    elif choice==2 :
        amount = float(input("Enter the withdraw amount: "))
        if amount>balance :
           print("Insufficient balance")
        else:
           balance = withdraw(amount,balance)
           print("Withdraw successfull")
    elif choice==3 :
        bal(name,balance)  
    else:
        print("Invalid choice! Please try again....")
    choice = float(input("Enter your next choice: "))
