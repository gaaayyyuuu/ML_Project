def factorial(num) :
    fact = 1
    if num==0 :
        return(1)
    else:
        fact = num*(factorial(num-1))
        return (fact)
num = int(input("Enter the number: "))
Result = factorial(num)
print("Factorial of ",num,"=",Result)