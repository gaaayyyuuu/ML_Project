num = int(input("Enter the number: "))
fact = 1
if num==0 :
    print("Factorial of 0 =",fact)
else:
    for i in range(1,num+1) :
        fact *= i
    print("Factorial of",num,"=",fact)