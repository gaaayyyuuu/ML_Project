import numpy as np
arr = np.array([10,20,30,40])
print(arr)
print(arr+5)
print(arr.mean())