str = input("Enter a sentence : ")
a = str.split()
b = len(a)
print("Number of words in the sentence is : ", b)